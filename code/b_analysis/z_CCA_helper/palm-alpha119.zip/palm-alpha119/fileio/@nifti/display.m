function display(obj)
% Display a NIFTI-1 object
%__________________________________________________________________________
% Copyright (C) 2005-2017 Wellcome Trust Centre for Neuroimaging

%
% $Id: display.m 7147 2017-08-03 14:07:01Z spm $


disp(' ');
disp([inputname(1),' = '])
disp(' ');
disp(obj)
disp(' ')
